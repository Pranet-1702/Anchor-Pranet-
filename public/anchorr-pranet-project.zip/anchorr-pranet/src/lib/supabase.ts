import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface DatabaseFeedback {
  id: string;
  full_name: string;
  organization: string | null;
  role: string;
  event_name: string | null;
  feedback: string;
  rating: number;
  public_consent: boolean;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  moderated_at: string | null;
}

// Read from client env vars
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured: boolean = Boolean(
  supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl.startsWith('https://') &&
    !supabaseUrl.includes('placeholder') &&
    !supabaseAnonKey.includes('placeholder')
);

let clientInstance: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient | null => {
  if (!isSupabaseConfigured) return null;
  if (!clientInstance) {
    clientInstance = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  }
  return clientInstance;
};

/**
 * SQL Schema & RLS Policies required for production deployment:
 * 
 * -- 1. Create table
 * CREATE TABLE public.feedbacks (
 *   id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 *   full_name TEXT NOT NULL,
 *   organization TEXT,
 *   role TEXT NOT NULL,
 *   event_name TEXT,
 *   feedback TEXT NOT NULL,
 *   rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
 *   public_consent BOOLEAN NOT NULL DEFAULT false,
 *   status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
 *   created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 *   moderated_at TIMESTAMPTZ
 * );
 * 
 * -- 2. Enable Row Level Security (RLS)
 * ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;
 * 
 * -- 3. Public policy: Anyone can submit a review with status 'pending'
 * CREATE POLICY "Public can insert pending feedback"
 *   ON public.feedbacks
 *   FOR INSERT
 *   TO anon, authenticated
 *   WITH CHECK (status = 'pending');
 * 
 * -- 4. Public policy: Anyone can read approved and consented reviews
 * CREATE POLICY "Public can read approved reviews"
 *   ON public.feedbacks
 *   FOR SELECT
 *   TO anon, authenticated
 *   USING (status = 'approved' AND public_consent = true);
 * 
 * -- 5. Admin policy: Authenticated admin users can view, update, and delete all reviews
 * CREATE POLICY "Admins have full access"
 *   ON public.feedbacks
 *   FOR ALL
 *   TO authenticated
 *   USING (true)
 *   WITH CHECK (true);
 */

export const REQUIRED_SQL_SCHEMA = `-- 1. Create feedbacks table
CREATE TABLE public.feedbacks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  organization TEXT,
  role TEXT NOT NULL,
  event_name TEXT,
  feedback TEXT NOT NULL,
  rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  public_consent BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  moderated_at TIMESTAMPTZ
);

-- 2. Enable Row Level Security
ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;

-- 3. Allow anonymous visitors to submit pending feedback
CREATE POLICY "Public insert pending feedback"
  ON public.feedbacks
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (status = 'pending');

-- 4. Allow public visitors to read only approved reviews
CREATE POLICY "Public select approved feedback"
  ON public.feedbacks
  FOR SELECT
  TO anon, authenticated
  USING (status = 'approved' AND public_consent = true);

-- 5. Authenticated administrators have full access to moderate
CREATE POLICY "Admin full moderation access"
  ON public.feedbacks
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);`;
