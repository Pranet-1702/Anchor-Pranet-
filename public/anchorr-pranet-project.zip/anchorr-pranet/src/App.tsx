/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { EventsExperience } from './components/EventsExperience';
import { PhotoGallery } from './components/PhotoGallery';
import { Achievements } from './components/Achievements';
import { Services } from './components/Services';
import { ClientFeedbackSection } from './components/ClientFeedbackSection';
import { DownloadPortfolio } from './components/DownloadPortfolio';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { LightboxModal } from './components/LightboxModal';
import { ParticleCanvas } from './components/ParticleCanvas';
import { FeedbackPage } from './components/FeedbackPage';
import { Phone, MessageSquare, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO } from './data/portfolioData';
import { GOOGLE_FORM_BOOKING_URL, WHATSAPP_BOOKING_URL } from './config/googleBookingConfig';

export default function App() {
  // Direct Routing: Check if URL path is /feedback
  const [currentRoute, setCurrentRoute] = useState<'home' | 'feedback'>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname.startsWith('/feedback') ? 'feedback' : 'home';
    }
    return 'home';
  });

  // Listen to browser back/forward history navigation
  useEffect(() => {
    const handlePopState = () => {
      if (window.location.pathname.startsWith('/feedback')) {
        setCurrentRoute('feedback');
      } else {
        setCurrentRoute('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateToHome = () => {
    if (typeof window !== 'undefined') {
      window.history.pushState(null, '', '/');
    }
    setCurrentRoute('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Lightbox Modal state
  const [selectedPhoto, setSelectedPhoto] = useState<{
    src: string;
    title: string;
    subtitle: string;
  } | null>(null);

  const handleSelectPhoto = (src: string, title: string, subtitle: string) => {
    setSelectedPhoto({ src, title, subtitle });
  };

  const handleExploreWork = () => {
    const el = document.getElementById('events');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Dedicated /feedback route view
  if (currentRoute === 'feedback') {
    return (
      <div className="min-h-screen bg-[#070709] text-[#fbf7ee] font-sans selection:bg-[#d4af37] selection:text-[#0a0a0c] relative">
        <ParticleCanvas />
        <FeedbackPage onNavigateHome={navigateToHome} />
      </div>
    );
  }

  // Main Portfolio View
  return (
    <div className="min-h-screen bg-[#070709] text-[#fbf7ee] font-sans selection:bg-[#d4af37] selection:text-[#0a0a0c] relative">
      {/* Background Interactive Gold Particle Dust (Hardware-accelerated, lightweight, pointer-events-none) */}
      <ParticleCanvas />

      {/* Top Navigation Bar adhering to Top Bar Contract */}
      <Navbar />

      {/* Main Content Sections */}
      <main id="main-content" className="relative z-10">
        {/* Section 1: Cinematic Hero with Animated Counters, Moving Light Trails & Depth */}
        <Hero
          onOpenBooking={() => {}}
          onExploreWork={handleExploreWork}
        />

        {/* Section 2: About Me & Stage Persona */}
        <About />

        {/* Section 3: Events & Experience (Filtered Categories & Event Modal) */}
        <EventsExperience
          onSelectPhoto={handleSelectPhoto}
        />

        {/* Section 4: Photo Gallery (Curated Masonry, Restrained Zoom & Full Image Viewer) */}
        <PhotoGallery onSelectPhoto={handleSelectPhoto} />

        {/* Section 5: Achievements & Honors */}
        <Achievements
          onSelectPhoto={handleSelectPhoto}
        />

        {/* Section 6: Anchoring & Emcee Services */}
        <Services onSelectServiceForBooking={() => {}} />

        {/* Section 7: Client Experiences & Feedback (Submissions, Share Controls, Empty State & Moderation) */}
        <ClientFeedbackSection />

        {/* Section 8: Download Anchoring Portfolio */}
        <DownloadPortfolio />

        {/* Section 9: Contact & Booking Enquiries */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Full-Screen Stage Photo Lightbox Modal */}
      <LightboxModal
        photo={selectedPhoto}
        onClose={() => setSelectedPhoto(null)}
        onSelectPhoto={handleSelectPhoto}
      />

      {/* Discreet Mobile Floating Action Bar (Height capped strictly <15% of viewport) */}
      <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-[#0a0a10]/95 backdrop-blur-lg border-t border-[#d4af37]/30 px-3 py-2.5 shadow-[0_-10px_25px_rgba(0,0,0,0.8)]">
        <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
          {/* Quick Call */}
          <a
            href={`tel:${PERSONAL_INFO.contact.rawPhone}`}
            aria-label="Call Pranet"
            className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#d4af37] border border-white/10 text-[11px] font-medium transition"
          >
            <Phone className="w-3.5 h-3.5 mb-0.5" />
            <span>Call</span>
          </a>

          {/* Quick WhatsApp with official prefilled message */}
          <a
            href={WHATSAPP_BOOKING_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp Pranet"
            className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 text-[#25D366] border border-[#25D366]/30 text-[11px] font-medium transition"
          >
            <MessageSquare className="w-3.5 h-3.5 mb-0.5" />
            <span>WhatsApp</span>
          </a>

          {/* Primary Book via Google Form (Direct New Tab) */}
          <a
            href={GOOGLE_FORM_BOOKING_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-[2] flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#e4c466] text-[#0a0a0c] text-xs font-bold uppercase tracking-wider shadow-[0_0_15px_rgba(212,175,55,0.35)] cursor-pointer text-center"
          >
            <span>Book Now</span>
            <ExternalLink className="w-3.5 h-3.5 shrink-0" />
          </a>
        </div>
      </div>
    </div>
  );
}
